public class Bolsa<T1> {
    private T1[] arregloT;

    public Bolsa() {
        // Initialize the class field directly (no need for local variable)
        arregloT = (T1[]) new Object[2]; // Create an array of Object and cast it
        System.out.println("Creaste una bolsa !");
    }

    public void agregar(T1 obj) {
        int n = arregloT.length;

        // Create a new array with increased size
        T1[] nuevoArreglo = (T1[]) new Object[n + 1];
        for (int i = 0; i < n; i++) {
            nuevoArreglo[i] = arregloT[i];
        }
        nuevoArreglo[n] = obj; // Add the new element to the end

        arregloT = nuevoArreglo; // Update the class field
    }
}
