"Emulogic" - Truetype Font
Copyright (c) 2004 by ck! [Freaky Fonts]. 
All rights reserved.

The personal, non-commercial use of my font is free.
But donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is sent to me.
Contact: www.freakyfonts.de
These font files may not be modified or renamed.
This readme file must be included with each font, unchanged.
Redistribute? 
Do not distribute without the author's permission, contact me first.

Visit .:Freaky Fonts:. for updates and more fonts (PC & MAC) :
www.freakyfonts.de

Thanks again to {ths} for the Mac conversion.
visit: www.ths.nu

Note:
For best results, use the font at 6 points and its multipliers: 12,18,24... 
Of course with anti-aliasing turned off.
Some Dingbats included...
All trademarks are property of their respective owners.