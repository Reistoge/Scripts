package clase04;

public class Biblioteca {
    // Declaración de un arreglo de objetos Libro llamado catalogo con una longitud de 10
    private Libro[] catalogo = new Libro[10];

    // Método para agregar un libro al catálogo de la biblioteca
    public void agregarLibro(Libro libro) {
        // Iteración sobre el catálogo para encontrar la primera posición disponible (donde el elemento es null)
        for (int i = 0; i < catalogo.length; i++) {
            if (catalogo[i] == null) {
                // Si se encuentra una posición disponible, se agrega el libro y se sale del bucle
                catalogo[i] = libro;
                break;
            }
        }
    }

    // Método para mostrar la información de todos los libros en el catálogo
    public void mostrarInformacion() {
        // Iteración sobre el catálogo
        for (int i = 0; i < catalogo.length; i++) {
            // Verificación de si la posición actual contiene un libro (no es null)
            if (catalogo[i] != null) {
                // Llamada al método mostrarInformacion() del objeto Libro en la posición actual
                catalogo[i].mostrarInformacion();
            }
        }
    }
}
