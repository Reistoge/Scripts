package clase04;

// Definición de la clase Libro
public class Libro {

    // Variables miembro privadas que representan las propiedades del libro
    private String titulo;
    private String autor;
    private int anoDePublicacion;

    // Constructor de la clase Libro que inicializa las propiedades
    public Libro(String titulo, String autor, int anoDePublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoDePublicacion = anoDePublicacion;
    }

    // Método para mostrar la información del libro en la consola
    public void mostrarInformacion() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Año de publicación: " + anoDePublicacion);
    }

    // Getter para obtener el valor del título
    public String getTitulo() {
        return titulo;
    }

    // Setter para establecer el valor del título
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Getter para obtener el valor del autor
    public String getAutor() {
        return autor;
    }

    // Setter para establecer el valor del autor
    public void setAutor(String autor) {
        this.autor = autor;
    }

    // Getter para obtener el valor del año de publicación
    public int getAnoDePublicacion() {
        return anoDePublicacion;
    }

    // Setter para establecer el valor del año de publicación
    public void setAnoDePublicacion(int anoDePublicacion) {
        this.anoDePublicacion = anoDePublicacion;
    }
}
