public class Car{
    
    int Id;
    String Mark;
    public Car(int I, String M){
        Id=I;
        Mark=M;
        System.out.println("you just created a instance of a Car !!! ");
        System.out.println(I+" "+M);
        
        
    }
    
    
}