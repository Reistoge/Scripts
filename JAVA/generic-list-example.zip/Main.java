/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.ArrayList;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    //ArrayList<Car> Cars=new ArrayList<Car>();
	    Car Car1=new Car(123,"Ferrari");
	    Car Car2=new Car(459,"Toyota");
	    Car Car3=new Car(999,"Supra");
	    //Cars.add(Car1);
	    
	    Bolsa<Car> CARS=new Bolsa<Car>();
	    CARS.agregar(Car1);
	    CARS.agregar(Car2);
	    CARS.agregar(Car3);
	    
	    
	    for(Car : CARS)
	    
	    
		// System.out.println("Hello World");
	}
}
