package clase04;

public class Main {

    public static void main(String[] args) {
        // Creación de una instancia de la clase Biblioteca
        Biblioteca biblioteca = new Biblioteca();

        // Creación de dos instancias de la clase Libro con datos específicos
        Libro libro1 = new Libro("El resplandor", "Stephen King", 1990);
        Libro libro2 = new Libro("100 años de soledad", "Gabriel Garcia Marquez", 1989);

        // Agregar los libros al catálogo de la biblioteca
        biblioteca.agregarLibro(libro1);
        biblioteca.agregarLibro(libro2);

        // Mostrar la información de todos los libros en el catálogo
        biblioteca.mostrarInformacion();
    }
}
